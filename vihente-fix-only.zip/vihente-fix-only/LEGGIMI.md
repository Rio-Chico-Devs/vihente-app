# FIX AUDIT — solo le novita' (54 file)

Questo pacchetto contiene SOLO i file cambiati dai 6 round di fix
dell'audit performance/qualita'. Presuppone che tu abbia GIA' applicato
il pacchetto CTA precedente (pacchetti/FAQ/timeline + api/contact.php +
public/.htaccess): quei file NON sono ripetuti qui, tranne dove i round
li hanno modificati di nuovo (Contacts, pagine servizio, GraficheShowcase,
vite.config, package.json — le versioni qui dentro sono le piu' recenti
e vincono su tutto).

## Come applicare

Copia le cartelle sopra la root del repo, sovrascrivendo. I path
rispecchiano il progetto: src/..., public/..., scripts/... (nuova).

## File da ELIMINARE a mano (se ancora presenti)

```
api/test-email.php
public/images/Chef.webp
public/images/Screenshot 2026-05-19 095916_converted.webp
public/images/websitesimage.webp
public/site.webmanifest
public/web-app-manifest-192x192.png
public/web-app-manifest-512x512.png
```

## Cosa fanno i file nuovi (mai visti prima)

```
scripts/stamp-sw.js        timbra la versione del service worker a fine
                           build (agganciato a "npm run build" nel
                           package.json incluso)
scripts/resize-images.sh   resize immagini sovradimensionate: dry-run di
                           default, --apply per eseguire (serve cwebp o
                           ImageMagick, in locale)
src/components/RouteMeta/  title/description/canonical per ogni route +
                           JSON-LD (montato da App.jsx incluso)
src/components/sections/NotFound/   pagina 404 (route catch-all in App.jsx)
```

## Dopo la copia

```
node security-audit.js    # 0 FAIL atteso
node integrity-scan.js    # 0 FAIL atteso
npm run build             # ora timbra anche il service worker
bash scripts/resize-images.sh          # dry-run
bash scripts/resize-images.sh --apply  # resize vero (commit prima!)
```

Se qualcosa non torna (es. NON avevi applicato il pacchetto CTA), usa
invece vihente-audit-fixes.zip che sta nella root del branch
claude/ecstatic-clarke-A1Fqv: contiene il delta completo rispetto a main.
