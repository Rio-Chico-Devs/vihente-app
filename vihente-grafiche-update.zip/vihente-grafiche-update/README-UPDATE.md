# AGGIORNAMENTO — sezione /portfolio/grafiche + fix vite.config

Questo pacchetto contiene SOLO le novita' rispetto allo stato attuale di
`main`. Non sovrascrive ne' duplica SYNC-INSTRUCTIONS.md, apply.sh,
ISTRUZIONI.txt che hai gia' su main.

## Cosa c'e' dentro (3 file)

```
src/components/sections/Portfolio/GraficheShowcase/GraficheShowcase.jsx
src/components/sections/Portfolio/GraficheShowcase/GraficheShowcase.css
vite.config.js
```

### 1. GraficheShowcase.jsx + .css

Refactor della sezione `/portfolio/grafiche`:

- **Gallery**: ogni card ora mostra l'immagine nella sua dimensione
  nativa (rispettando l'aspect ratio), con un cap massimo di 200x200 su
  desktop e 180x180 su mobile. Le immagini 3:4, 16:9, ecc. mantengono
  le loro proporzioni invece di essere forzate in un quadrato.
- **Modal**: si adatta all'aspect ratio dell'immagine (non e' piu'
  fisso a 80vh). Interazioni:
  - **Rotella mouse** = zoom in/out (0.5x ... 6x)
  - **Click + drag** = pan (sposta l'immagine zoomata)
  - **Doppio click** = reset zoom + posizione
  - **Pulsanti +/-/RESET** = stesso effetto dei comandi mouse
  - Touch screen: drag con un dito = pan, pinch zoom da tastiera non
    implementato (per ora rotella + pulsanti).

Se un'immagine non esiste in `/public/images/`, fa fallback al
placeholder testuale (il vecchio comportamento). Quindi puoi caricare le
immagini una alla volta senza rompere nulla.

### 2. vite.config.js

Sul main attuale c'e' una sintassi malformata in fondo al file
(`}   }))` con un `}` di troppo): vite builda lo stesso solo perche'
parser-tollerante, ma e' codice rotto. Questa versione lo fixa
ripristinando il corretto `}))`.

## Immagini attese

In `/public/images/` (formato `.webp` consigliato, ma anche `.jpg`/`.png`
vanno bene se cambi l'estensione nel JSX). Mantengono il loro aspect
ratio nativo:

```
grafiche-logo-tech.webp
grafiche-icon-app.webp
grafiche-illustration-editorial.webp
grafiche-brand-identity.webp
grafiche-poster-event.webp
grafiche-packaging-product.webp
grafiche-social-media.webp
grafiche-infographic.webp
grafiche-character-design.webp
grafiche-web-design.webp
```

## Cosa fare (manuale, 30 secondi)

1. Estrai lo zip.
2. Copia i 3 file sopra il repo `main`, sovrascrivendo.
3. **Cancella manualmente `api/test-email.php`** se ancora presente.
   Era una utility di test esposta pubblicamente che mostra la versione
   di PHP e permette di mandare email arbitrarie - va rimosso prima del
   deploy.

Niente apply.sh stavolta: 3 file si copiano a mano in 10 secondi.

Dopo:
```
node security-audit.js   # 0 FAIL atteso
node integrity-scan.js   # 0 FAIL atteso
npm run build            # verifica che la build sia pulita
```
