import { useState, useRef, useEffect, useCallback } from 'react';
import './FemosBlackMarketPage.css';
import { useGuide } from '../../../../../contexts/GuideContext';

// Costanti e database fuori dal componente per evitare problemi di dipendenze
const CART_MAX_ITEMS = 12;

const productsDatabase = [
  // SPECIAL (2 tipi, max 1 generabile)
  { id: 1, name: "Carnivals Deck", price: 9999, rarity: "special", image: "/shop/carnivals.webp", desc: "Un sogno che diventa realtà?", maxStock: 1, baseStock: 1 },
  { id: 36, name: "Connessione Eterna", price: 9999, rarity: "special", image: "/shop/connessione-eterna.webp", desc: "Collegati, per sempre.", maxStock: 1, baseStock: 1 },

  // ??? (1 solo tipo, max 1 generabile, ultra raro)
  { id: 2, name: "La Chiave", price: 99999, rarity: "mystery", image: "/shop/chiave-gialla.webp", desc: "Non sembra essere utile da sola.", maxStock: 1, baseStock: 1 },

  // LEGENDARY (4 tipi diversi, max 1 generabile)
  { id: 3, name: "Phoesia", price: 2999, rarity: "legendary", image: "/shop/Phoesia.webp", desc: "Qualcuno privò un essere di una frazione della sua bellezza, scrisse 1000 poesie, perfette, come fosse magia.", maxStock: 1, baseStock: 1 },
  { id: 4, name: "Mistery Blessing", price: 3499, rarity: "legendary", image: "/shop/mistery-blessing.webp", desc: "A tutti piacciono le sorprese... finchè rimangono sorprese...", maxStock: 1, baseStock: 1 },
  { id: 5, name: "Oni", price: 4299, rarity: "legendary", image: "/shop/Oni.webp", desc: "Apparteneva a un bambino pieno di speranze, queste speranze non morirono mai e vissero dentro il suo peluche preferito.", maxStock: 1, baseStock: 1 },
  { id: 6, name: "Arcobalecaedro", price: 3799, rarity: "legendary", image: "/shop/arcobalecaedro.webp", desc: "Qualcuno è riuscito a catturarci dentro l'impossibile, in tutti i suoi 7 colori.", maxStock: 1, baseStock: 1 },

  // EPIC (6 tipi diversi, max 2 generabili)
  { id: 7, name: "Profondo Blu", price: 1499, rarity: "epic", image: "/shop/profondo-blu.webp", desc: "Molto, molto lontano, esistono tonalità di blu ancora più forti e ipnotiche. Dona un incredibile sollievo.", maxStock: 2, baseStock: 2 },
  { id: 8, name: "Cuor di Leone", price: 1899, rarity: "epic", image: "/shop/Cuor-di-leone.webp", desc: "Qualcuno lo ha perso, io l'ho trovato in un luogo dimenticato, deve aver avuto molto coraggio per sopravvivere.", maxStock: 2, baseStock: 2 },
  { id: 9, name: "United We Stand", price: 1699, rarity: "epic", image: "/shop/united-we-stand.webp", desc: "Uniti resistiamo, fino alla fine. Resta con me.", maxStock: 2, baseStock: 2 },
  { id: 10, name: "Avidità", price: 2199, rarity: "epic", image: "/shop/avidita.webp", desc: "L'uomo più avido scomparì nel nulla, al suo posto trovarono solo questo...", maxStock: 2, baseStock: 2 },
  { id: 11, name: "Idolo Sconosciuto", price: 1799, rarity: "epic", image: "/shop/idolo-sconosciuto.webp", desc: "Produce dei suoni ritmici interessanti, nessuno sa a cosa serve...", maxStock: 2, baseStock: 2 },
  { id: 12, name: "Oltre Il Nulla", price: 1599, rarity: "epic", image: "/shop/oltre-il-nulla.webp", desc: "Queste pagine raccontano un'avventura oltre ogni immaginazione", maxStock: 2, baseStock: 2 },

  // RARE (8 tipi diversi, max 3 generabili)
  { id: 13, name: "Prigione dei sensi", price: 599, rarity: "rare", image: "/shop/prigione-sensi.webp", desc: "Privati dei propri sensi non siamo altro che contenitori. Allontana le minacce.", maxStock: 3, baseStock: 3 },
  { id: 14, name: "Cima della fragilità", price: 799, rarity: "rare", image: "/shop/cima-fragilita.webp", desc: "Forgiato con molte speranze. Aumenta la prospettiva.", maxStock: 3, baseStock: 3 },
  { id: 15, name: "No Pain No Gain", price: 1099, rarity: "rare", image: "/shop/no-pain-no-gain.webp", desc: "Tutto vale il giusto prezzo. Sacrifichi salute per avere più potenza.", maxStock: 3, baseStock: 3 },
  { id: 16, name: "Incubi Istantanei", price: 899, rarity: "rare", image: "/shop/incubi-istantanei.webp", desc: "Infligge danni pesanti su soggetti addormentati.", maxStock: 3, baseStock: 3 },
  { id: 17, name: "Anti Malocchio", price: 949, rarity: "rare", image: "/shop/anti-malocchio.webp", desc: "A nessuno piace avere una brutta giornata, elimina status di sfortuna.", maxStock: 3, baseStock: 3 },
  { id: 18, name: "Demone Interiore", price: 1199, rarity: "rare", image: "/shop/demone-interiore.webp", desc: "Ognuno ha i suoi scheletri. Aumenta la potenza ma aumenta anche lo stress.", maxStock: 3, baseStock: 3 },
  { id: 19, name: "Divine Soup", price: 749, rarity: "rare", image: "/shop/divine-soup.webp", desc: "Non è succo di pomodoro... Aumenta la salute di molto ma aumenta lo stress.", maxStock: 3, baseStock: 3 },
  { id: 20, name: "Pensieri Oscuri", price: 699, rarity: "rare", image: "/shop/Pensieri-oscuri.webp", desc: "Aumenta lo stress, meglio non usarlo su se stessi.", maxStock: 3, baseStock: 3 },

  // COMMON (15 tipi diversi, stock abbondante)
  { id: 21, name: "Magnet Pull", price: 299, rarity: "common", image: "/shop/magnet-pull.webp", desc: "Attrae ogni sorta di cosa in un lampo.", maxStock: 8, baseStock: 8 },
  { id: 22, name: "Lume", price: 199, rarity: "common", image: "/shop/lume.webp", desc: "illumina anche l'oscurità più fitta.", maxStock: 8, baseStock: 8 },
  { id: 23, name: "Eye C Yu", price: 349, rarity: "common", image: "/shop/eye-c-yu.webp", desc: "Ormai la privacy non esiste più... Individua tutto.", maxStock: 8, baseStock: 8 },
  { id: 24, name: "Karma Flasks", price: 149, rarity: "common", image: "/shop/karma-flasks.webp", desc: "Recupera una buona dose di Karma.", maxStock: 8, baseStock: 8 },
  { id: 25, name: "Etereonite", price: 249, rarity: "common", image: "/shop/etereonite.webp", desc: "Tipico materiale energetico.", maxStock: 8, baseStock: 8 },
  { id: 26, name: "Cura Massima", price: 179, rarity: "common", image: "/shop/cura-massima.webp", desc: "Ripristina molta salute.", maxStock: 8, baseStock: 8 },
  { id: 27, name: "Hp-Plus", price: 229, rarity: "common", image: "/shop/hp-plus.webp", desc: "Recupera una dose di salute normale.", maxStock: 8, baseStock: 8 },
  { id: 28, name: "Flashbanger", price: 189, rarity: "common", image: "/shop/flashbanger.webp", desc: "Boom. Correre.", maxStock: 8, baseStock: 8 },
  { id: 29, name: "Passpartout", price: 399, rarity: "common", image: "/shop/passpartout.webp", desc: "Entra dove vuoi, sei il padrone di casa.", maxStock: 8, baseStock: 8 },
  { id: 30, name: "Passionate Soul", price: 279, rarity: "common", image: "/shop/passionate-soul.webp", desc: "Brucia il mondo, un pò alla volta...", maxStock: 8, baseStock: 8 },
  { id: 31, name: "Milky Way", price: 199, rarity: "common", image: "/shop/milky-way.webp", desc: "Ripristina una dose bassa di Karma e salute.", maxStock: 8, baseStock: 8 },
  { id: 32, name: "Passione Liquida", price: 159, rarity: "common", image: "/shop/passione-liquida.webp", desc: "Ripristina una buone dose di Energia", maxStock: 8, baseStock: 8 },
  { id: 33, name: "Spaccamenti", price: 449, rarity: "common", image: "/shop/spacca-menti.webp", desc: "Elimina lo stress.", maxStock: 8, baseStock: 8 },
  { id: 34, name: "Misuratore", price: 299, rarity: "common", image: "/shop/vital-checker.webp", desc: "Misura le tue statistiche.", maxStock: 8, baseStock: 8 },
  { id: 35, name: "Vecchio Giocattolo", price: 549, rarity: "common", image: "/shop/vecchio-giocattolo.webp", desc: "Un tenero ricordo... aumenta il karma nel tempo.", maxStock: 8, baseStock: 8 }
];

const mascotPhrases = {
  mystery: ["...?", "èwì97 djw9<5 _swo", "..."],
  special: ["ATTENZIONE: Artefatto di classe SPECIAL. Pericolo estremo.", "Questo... non dovrebbe esistere. Ma eccolo qui.", "Solo per i più folli. O i più coraggiosi. Forse entrambi."],
  legendary: ["RARO. Molto raro. Forse troppo per te?", "Pezzo unico. Una volta venduto, sparisce per sempre.", "Potere leggendario. Gestiscilo con rispetto."],
  epic: ["Qualità superiore. Per operatori esperti.", "Stock limitato. Non ricapita spesso.", "Ottima scelta. Sopravviverai più a lungo."],
  rare: ["Solido. Affidabile. Sopra la media.", "Ne ho pochi. Meglio prenderlo ora.", "Buon compromesso tra prezzo e prestazioni."],
  common: ["L'essenziale. Ogni runner ne ha bisogno.", "Economico. Funzionale. Semplice.", "Stock pieno. Ne ho quanti ne vuoi."],
  cart: ["Il tuo arsenale cresce... interessante.", "Buon occhio per gli affari.", "Stai pianificando qualcosa di grosso?"],
  cartFull: ["HEY. Hai già troppa roba. Sgombera il carrello.", "STOP. Il carrello è pieno. Compra prima.", "Non puoi portare altro. Limiti fisici, capisci?"],
  noStock: ["Esaurito. Finito. Venduto. Puff.", "Ne avevo uno. HAD. Past tense.", "Troppo tardi. Qualcun altro è stato più veloce."],
  purchase: ["Transazione completata. Materiale in consegna.", "Piacere fare affari. Ci vediamo presto.", "Vendita confermata. Il mercato nero non dimentica."],
  randomize: ["Nuovo shipment. Controlla l'inventario.", "Ho rifornito. Potrebbero esserci sorprese.", "Merce fresca dal mercato nero."]
};

const FemosBlackMarketPage = () => {
  const { setGuide, clearGuide } = useGuide();
  const [simulationActive, setSimulationActive] = useState(false);
  const [currentPage, setCurrentPage] = useState('shop');
  const [cart, setCart] = useState([]);
  const [mascotMessage, setMascotMessage] = useState("Il mercato nero ti dà il benvenuto...");
  const [pupilPosition, setPupilPosition] = useState({ x: 500, y: 500 });
  const [checkoutData, setCheckoutData] = useState({
    name: '', email: '', address: '', city: '', zip: '', wallet: ''
  });
  const [pageTransition, setPageTransition] = useState(false);

  const eyeRef = useRef(null);
  const targetPositionRef = useRef({ x: 500, y: 500 });
  const currentPositionRef = useRef({ x: 500, y: 500 });
  const interpolationFrameRef = useRef(null);

  const [productStock, setProductStock] = useState(() => {
    const initialStock = {};
    productsDatabase.forEach(product => {
      initialStock[product.id] = product.baseStock;
    });
    return initialStock;
  });

  const [currentProducts, setCurrentProducts] = useState([]);

  const generateShopInventory = useCallback(() => {
    const isMobile = window.innerWidth <= 768;
    const maxProducts = isMobile ? 4 : 10;
    
    // Pesi di rarità: mystery è ancora più raro di special
    const rarityWeights = { 
      mystery: 0.1,    // 0.1% - ultra raro
      special: 0.5,    // 0.5% - molto raro
      legendary: 4,    // 4%
      epic: 10,        // 10%
      rare: 25,        // 25%
      common: 60.4     // 60.4% - resto
    };
    
    // Limiti massimi per rarità nello shop
    const rarityLimits = {
      mystery: 1,
      special: 1,
      legendary: 1,
      epic: 2,
      rare: 3
      // common: nessun limite
    };
    
    const availableProducts = productsDatabase.filter(p => productStock[p.id] > 0);
    const selectedProducts = [];
    const usedIds = new Set();
    const rarityCounts = { mystery: 0, special: 0, legendary: 0, epic: 0, rare: 0, common: 0 };

    while (selectedProducts.length < maxProducts && availableProducts.length > 0) {
      const rand = Math.random() * 100;
      let cumulativeProbability = 0;
      let selectedRarity = 'common';

      for (const [rarity, weight] of Object.entries(rarityWeights)) {
        cumulativeProbability += weight;
        if (rand <= cumulativeProbability) {
          selectedRarity = rarity;
          break;
        }
      }
      
      // Controlla se la rarità ha raggiunto il limite
      if (rarityLimits[selectedRarity] && rarityCounts[selectedRarity] >= rarityLimits[selectedRarity]) {
        // Se il limite è raggiunto, riparte il ciclo per selezionare un'altra rarità
        continue;
      }

      const rarityProducts = availableProducts.filter(p => p.rarity === selectedRarity && !usedIds.has(p.id));
      if (rarityProducts.length > 0) {
        const randomProduct = rarityProducts[Math.floor(Math.random() * rarityProducts.length)];
        selectedProducts.push(randomProduct);
        usedIds.add(randomProduct.id);
        rarityCounts[selectedRarity]++;
      }
    }

    // Riempi gli slot rimanenti con prodotti comuni o rare se non si raggiunge il maxProducts
    while (selectedProducts.length < maxProducts && availableProducts.length > selectedProducts.length) {
      const remainingProducts = availableProducts.filter(p => {
        if (usedIds.has(p.id)) return false;
        
        // Controlla i limiti
        if (rarityLimits[p.rarity] && rarityCounts[p.rarity] >= rarityLimits[p.rarity]) {
          return false;
        }
        
        return true;
      });
      
      if (remainingProducts.length === 0) break;
      const randomProduct = remainingProducts[Math.floor(Math.random() * remainingProducts.length)];
      selectedProducts.push(randomProduct);
      usedIds.add(randomProduct.id);
      rarityCounts[randomProduct.rarity]++;
    }

    setCurrentProducts(selectedProducts);
  }, [productStock]);

  useEffect(() => {
    if (simulationActive && currentProducts.length === 0) {
      generateShopInventory();
    }
  }, [simulationActive, currentProducts.length, generateShopInventory]);

  useEffect(() => {
    if (!simulationActive) return;

    const smoothness = 0.15;
    function interpolate() {
      const current = currentPositionRef.current;
      const target = targetPositionRef.current;
      const dx = target.x - current.x;
      const dy = target.y - current.y;

      if (Math.abs(dx) < 0.1 && Math.abs(dy) < 0.1) {
        current.x = target.x;
        current.y = target.y;
      } else {
        current.x += dx * smoothness;
        current.y += dy * smoothness;
      }

      setPupilPosition({ x: current.x, y: current.y });
      interpolationFrameRef.current = requestAnimationFrame(interpolate);
    }

    interpolate();
    return () => {
      if (interpolationFrameRef.current) cancelAnimationFrame(interpolationFrameRef.current);
    };
  }, [simulationActive]);

  useEffect(() => {
    if (!simulationActive) return;

    const handleMouseMove = (e) => {
      if (!eyeRef.current) return;

      const eyeRect = eyeRef.current.getBoundingClientRect();
      const relativeX = (e.clientX - eyeRect.left) / eyeRect.width;
      const relativeY = (e.clientY - eyeRect.top) / eyeRect.height;

      const svgWidth = 1000, svgHeight = 1000;
      let newX = relativeX * svgWidth;
      let newY = relativeY * svgHeight;

      const centerX = 500, centerY = 500;
      const maxRadiusX = 95, maxRadiusY = 65;
      const deltaFromCenterX = newX - centerX;
      const deltaFromCenterY = newY - centerY;

      const normalizedDistance = Math.sqrt(
        (deltaFromCenterX * deltaFromCenterX) / (maxRadiusX * maxRadiusX) +
        (deltaFromCenterY * deltaFromCenterY) / (maxRadiusY * maxRadiusY)
      );

      if (normalizedDistance > 1) {
        const angle = Math.atan2(deltaFromCenterY, deltaFromCenterX);
        newX = centerX + Math.cos(angle) * maxRadiusX;
        newY = centerY + Math.sin(angle) * maxRadiusY;
      }

      targetPositionRef.current = { x: newX, y: newY };
    };

    window.addEventListener('mousemove', handleMouseMove);
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, [simulationActive]);

  const startSimulation = () => {
    setSimulationActive(true);
    setMascotMessage("Benvenuto, runner. Scegli con saggezza.");
  };

  const exitSimulation = () => {
    setSimulationActive(false);
    setCart([]);
    setCurrentPage('shop');
    setMascotMessage("Il mercato nero ti dà il benvenuto...");
    setCheckoutData({ name: '', email: '', address: '', city: '', zip: '', wallet: '' });
    setCurrentProducts([]);
    const resetStock = {};
    productsDatabase.forEach(product => { resetStock[product.id] = product.baseStock; });
    setProductStock(resetStock);
  };

  const randomizeShop = () => {
    generateShopInventory();
    const randomPhrase = mascotPhrases.randomize[Math.floor(Math.random() * mascotPhrases.randomize.length)];
    setMascotMessage(randomPhrase);
  };

  const navigateToPage = (page) => {
    setPageTransition(true);
    setTimeout(() => {
      setCurrentPage(page);
      setPageTransition(false);
    }, 300);
  };

  const addToCart = (product) => {
    if (productStock[product.id] <= 0) {
      const randomPhrase = mascotPhrases.noStock[Math.floor(Math.random() * mascotPhrases.noStock.length)];
      setMascotMessage(randomPhrase);
      return;
    }

    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    if (totalItems >= CART_MAX_ITEMS) {
      const randomPhrase = mascotPhrases.cartFull[Math.floor(Math.random() * mascotPhrases.cartFull.length)];
      setMascotMessage(randomPhrase);
      return;
    }

    const existing = cart.find(item => item.id === product.id);
    const currentQty = existing ? existing.quantity : 0;

    if (currentQty >= productStock[product.id]) {
      const randomPhrase = mascotPhrases.noStock[Math.floor(Math.random() * mascotPhrases.noStock.length)];
      setMascotMessage(randomPhrase);
      return;
    }

    if (existing) {
      setCart(cart.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item));
    } else {
      setCart([...cart, { ...product, quantity: 1 }]);
    }

    const randomPhrase = mascotPhrases.cart[Math.floor(Math.random() * mascotPhrases.cart.length)];
    setMascotMessage(randomPhrase);
  };

  const removeFromCart = (productId) => {
    setCart(cart.filter(item => item.id !== productId));
    setMascotMessage("Rimosso. Cambiato idea?");
  };

  const updateQuantity = (productId, change) => {
    setCart(cart.map(item => {
      if (item.id === productId) {
        const newQty = item.quantity + change;
        if (newQty > productStock[productId]) {
          setMascotMessage("Stock insufficiente.");
          return item;
        }
        return newQty > 0 ? { ...item, quantity: newQty } : item;
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const getTotalPrice = () => cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
  const getTotalItems = () => cart.reduce((sum, item) => sum + item.quantity, 0);

  const sanitizeInput = (input) => input.replace(/[<>]/g, '').replace(/javascript:/gi, '').replace(/on\w+=/gi, '').trim().slice(0, 200);
  const validateEmail = (email) => /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/.test(email);
  const validateWallet = (wallet) => /^0x[a-fA-F0-9]{40}$/.test(wallet);

  const handleCheckout = (e) => {
    e.preventDefault();

    const sanitizedData = {
      name: sanitizeInput(checkoutData.name),
      email: sanitizeInput(checkoutData.email),
      address: sanitizeInput(checkoutData.address),
      city: sanitizeInput(checkoutData.city),
      zip: sanitizeInput(checkoutData.zip),
      wallet: sanitizeInput(checkoutData.wallet)
    };

    if (!sanitizedData.name || sanitizedData.name.length < 2) {
      setMascotMessage("Nome non valido. Minimo 2 caratteri.");
      return;
    }
    if (!validateEmail(sanitizedData.email)) {
      setMascotMessage("Email non valida. Formato corretto richiesto.");
      return;
    }
    if (!sanitizedData.address || sanitizedData.address.length < 5) {
      setMascotMessage("Indirizzo non valido. Minimo 5 caratteri.");
      return;
    }
    if (!sanitizedData.city || sanitizedData.city.length < 2) {
      setMascotMessage("Città non valida. Minimo 2 caratteri.");
      return;
    }
    if (!/^\d{5}$/.test(sanitizedData.zip)) {
      setMascotMessage("CAP non valido. 5 cifre richieste.");
      return;
    }
    if (!validateWallet(sanitizedData.wallet)) {
      setMascotMessage("Wallet ID non valido. Formato: 0x + 40 caratteri hex.");
      return;
    }

    const newStock = { ...productStock };
    cart.forEach(item => { newStock[item.id] = Math.max(0, newStock[item.id] - item.quantity); });
    setProductStock(newStock);

    const randomPhrase = mascotPhrases.purchase[Math.floor(Math.random() * mascotPhrases.purchase.length)];
    setMascotMessage(randomPhrase);

    setTimeout(() => exitSimulation(), 2000);
  };

  const handleInputChange = (field, value) => {
    setCheckoutData({ ...checkoutData, [field]: value });
  };

  const getRarityColor = (rarity) => {
    switch(rarity) {
      case 'mystery': return 'rgba(138, 43, 226, 1)'; // Viola scuro/nero con sfumature
      case 'special': return 'rgba(255, 20, 147, 1)';
      case 'legendary': return 'rgba(255, 215, 0, 0.9)';
      case 'epic': return 'rgba(163, 53, 238, 0.9)';
      case 'rare': return 'rgba(0, 149, 255, 0.9)';
      case 'common': return 'rgba(0, 255, 255, 0.7)';
      default: return 'rgba(0, 255, 255, 0.6)';
    }
  };

  const getRarityLabel = (rarity) => {
    const labels = { mystery: '???', special: 'SPECIAL', legendary: 'LEGENDARY', epic: 'EPIC', rare: 'RARE', common: 'COMMON' };
    return labels[rarity] || rarity.toUpperCase();
  };

  if (!simulationActive) {
    return (
      <div className="start-screen">
        <div className="start-content">
          <h1 className="market-title persona-title">FEMO'S<br/>BLACK MARKET</h1>
          <p className="market-subtitle">// DOVE I RUNNER TROVANO IL LORO EQUIPAGGIAMENTO //</p>
          <button className="start-btn persona-btn" onClick={startSimulation}>
            <span className="btn-glitch" data-text="► INIZIA SIMULAZIONE">► INIZIA SIMULAZIONE</span>
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="black-market">
      <div className={`market-content ${pageTransition ? 'page-transition' : ''}`}>
        <div className="market-header persona-header">
          <h1 className="header-title persona-title-small">FEMO'S BLACK MARKET</h1>
          <div className="header-actions">
            {currentPage === 'shop' && (
              <>
                <button className="btn persona-btn" onClick={randomizeShop} onMouseEnter={() => setGuide('Rifornisce il negozio con nuovi prodotti casuali — ogni click cambia l\'inventario.')} onMouseLeave={clearGuide}>🎲 RANDOMIZZA</button>
                <button className="btn cart-btn persona-btn" onClick={() => navigateToPage('cart')}>
                  🛒 CARRELLO
                  {cart.length > 0 && <span className="cart-count persona-cart-badge">{cart.length}</span>}
                </button>
              </>
            )}
            {currentPage === 'cart' && <button className="btn persona-btn" onClick={() => navigateToPage('shop')}>← SHOP</button>}
            {currentPage === 'checkout' && <button className="btn persona-btn" onClick={() => navigateToPage('cart')}>← CARRELLO</button>}
            <button className="btn btn-danger persona-btn" onClick={exitSimulation}>✕ ESCI</button>
          </div>
        </div>

        {currentPage === 'shop' && (
          <div className="products-section">
            <div className="section-header" onMouseEnter={() => setGuide('Inventario del mercato nero — ogni refresh cambia i prodotti disponibili con rarità casuali: common, rare, epic, legendary e mystery.')} onMouseLeave={clearGuide}>
              <h2 className="section-title persona-section-title">// INVENTARIO //</h2>
            </div>
            <div className="products-grid">
              {currentProducts.map((product, index) => (
                <div
                  key={product.id}
                  className="product-card persona-card"
                  data-rarity={product.rarity}
                  style={{ 
                    color: getRarityColor(product.rarity),
                    animationDelay: `${index * 0.1}s`
                  }}
                  onMouseEnter={() => {
                    const phrases = mascotPhrases[product.rarity];
                    setMascotMessage(phrases[Math.floor(Math.random() * phrases.length)]);
                    if (product.rarity === 'mystery' || product.rarity === 'special') {
                      setGuide('E quella roba chi l\'ha messa lì? o_o');
                    }
                  }}
                  onMouseLeave={clearGuide}
                >
                  <span className="rarity-badge persona-badge" style={{ backgroundColor: getRarityColor(product.rarity), color: '#000', borderColor: getRarityColor(product.rarity) }}>
                    {getRarityLabel(product.rarity)}
                  </span>
                  <div className="stock-badge" style={{ border: `1px solid ${getRarityColor(product.rarity)}`, color: getRarityColor(product.rarity) }}>
                    STOCK: {productStock[product.id]}/{product.maxStock}
                  </div>
                  <div className="product-image">
                    <img
                      src={product.image}
                      alt={product.name}
                      style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 'inherit' }}
                      onError={(e) => { e.currentTarget.style.display = 'none'; e.currentTarget.nextSibling.style.display = 'flex'; }}
                    />
                    <span style={{ display: 'none', width: '100%', height: '100%', alignItems: 'center', justifyContent: 'center', fontSize: '2rem' }}>📦</span>
                  </div>
                  <div className="product-info">
                    <h3 className="product-name">{product.name}</h3>
                    <p className="product-desc">{product.desc}</p>
                    <div className="product-price persona-price">₿{product.price}</div>
                  </div>
                  <button className="add-to-cart-btn persona-btn" onClick={() => addToCart(product)} disabled={productStock[product.id] <= 0}>
                    {productStock[product.id] <= 0 ? '✕ ESAURITO' : '+ AGGIUNGI'}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        {currentPage === 'cart' && (
          <div className="cart-section" onMouseEnter={() => setGuide('Aggiungi prodotti, modifica le quantità e procedi al checkout.')} onMouseLeave={clearGuide}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: '2rem' }}>
              <h2 className="section-title persona-section-title">// INVENTARIO RUNNER //</h2>
              <div style={{ color: getTotalItems() >= CART_MAX_ITEMS ? '#ff0055' : '#0ff', fontSize: '1.1rem', fontWeight: '700' }}>
                {getTotalItems()}/{CART_MAX_ITEMS} ITEMS
              </div>
            </div>

            {cart.length === 0 ? (
              <div className="empty-cart">
                <div className="empty-cart-icon">📭</div>
                <p style={{ fontSize: '1.2rem', marginBottom: '0.5rem' }}>INVENTARIO VUOTO</p>
                <p style={{ fontSize: '0.9rem' }}>Il runner viaggia leggero...</p>
                <button className="btn persona-btn" style={{ marginTop: '2rem' }} onClick={() => navigateToPage('shop')}>
                  → TORNA AL MERCATO
                </button>
              </div>
            ) : (
              <>
                <div className="cart-items">
                  {cart.map((item, index) => (
                    <div key={item.id} className="cart-item persona-card" style={{ animationDelay: `${index * 0.05}s` }}>
                      <div className="cart-item-image">
                        <img
                          src={item.image}
                          alt={item.name}
                          style={{ width: '100%', height: '100%', objectFit: 'cover', borderRadius: 'inherit' }}
                          onError={(e) => { e.currentTarget.style.display = 'none'; e.currentTarget.nextSibling.style.display = 'block'; }}
                        />
                        <span style={{ display: 'none', fontSize: '1.5rem' }}>📦</span>
                        <div style={{
                          position: 'absolute', bottom: '-5px', right: '-5px', width: '20px', height: '20px',
                          background: getRarityColor(item.rarity), borderRadius: '50%', border: '2px solid #000'
                        }}></div>
                      </div>
                      <div className="cart-item-info">
                        <div className="cart-item-name">{item.name}</div>
                        <div className="cart-item-price">₿{item.price} × {item.quantity}</div>
                        <div style={{ fontSize: '0.75rem', color: getRarityColor(item.rarity), marginTop: '0.25rem', textTransform: 'uppercase', fontWeight: '600' }}>
                          {getRarityLabel(item.rarity)} • MAX: {item.maxStock}
                        </div>
                      </div>
                      <div className="quantity-controls">
                        <button className="qty-btn persona-btn-small" onClick={() => updateQuantity(item.id, -1)}>-</button>
                        <span className="qty-value">{item.quantity}</span>
                        <button className="qty-btn persona-btn-small" onClick={() => updateQuantity(item.id, 1)} disabled={item.quantity >= productStock[item.id]}>+</button>
                      </div>
                      <button className="remove-btn persona-btn-small" onClick={() => removeFromCart(item.id)}>✕</button>
                    </div>
                  ))}
                </div>

                <div className="cart-summary persona-summary">
                  <div className="summary-row"><span>SUBTOTALE:</span><span style={{ color: '#0ff' }}>₿{getTotalPrice()}</span></div>
                  <div className="summary-row"><span>TASSA MERCATO NERO:</span><span style={{ color: '#0ff' }}>₿0</span></div>
                  <div className="summary-row"><span>ITEMS TOTALI:</span><span style={{ color: '#0ff' }}>{getTotalItems()}</span></div>
                  <div className="summary-row summary-total"><span>TOTALE:</span><span>₿{getTotalPrice()}</span></div>
                </div>

                <button className="btn persona-btn" style={{ width: '100%', padding: '1rem', fontSize: '1.1rem' }} onClick={() => navigateToPage('checkout')}>
                  → PROCEDI AL TRASFERIMENTO
                </button>
              </>
            )}
          </div>
        )}

        {currentPage === 'checkout' && (
          <div className="cart-section">
            <h2 className="section-title persona-section-title" style={{ marginBottom: '2rem' }}>// PROTOCOLLO TRASFERIMENTO //</h2>

            <form className="checkout-form persona-form" onSubmit={handleCheckout}>
              <div style={{
                background: 'rgba(255, 0, 85, 0.1)', border: '1px solid rgba(255, 0, 85, 0.3)', borderRadius: '4px',
                padding: '1rem', marginBottom: '2rem', fontSize: '0.85rem', color: 'rgba(255, 255, 255, 0.8)'
              }}>
                ⚠️ ATTENZIONE: Tutti i dati vengono validati. Formato wallet: 0x + 40 caratteri hex.
              </div>

              <div className="form-group">
                <label className="form-label">IDENTITÀ RUNNER</label>
                <input type="text" className="form-input persona-input" value={checkoutData.name} onChange={(e) => handleInputChange('name', e.target.value)} placeholder="Nome completo (min. 2 caratteri)" maxLength="200" required />
              </div>

              <div className="form-group">
                <label className="form-label">CANALE COMUNICAZIONE</label>
                <input type="email" className="form-input persona-input" value={checkoutData.email} onChange={(e) => handleInputChange('email', e.target.value)} placeholder="email@domain.com" maxLength="200" required />
              </div>

              <div className="form-group">
                <label className="form-label">COORDINATE DROP-POINT</label>
                <input type="text" className="form-input persona-input" value={checkoutData.address} onChange={(e) => handleInputChange('address', e.target.value)} placeholder="Via, numero civico (min. 5 caratteri)" maxLength="200" required />
              </div>

              <div className="form-group">
                <label className="form-label">ZONA OPERATIVA</label>
                <input type="text" className="form-input persona-input" value={checkoutData.city} onChange={(e) => handleInputChange('city', e.target.value)} placeholder="Città (min. 2 caratteri)" maxLength="200" required />
              </div>

              <div className="form-group">
                <label className="form-label">CODICE POSTALE</label>
                <input type="text" className="form-input persona-input" value={checkoutData.zip} onChange={(e) => handleInputChange('zip', e.target.value)} placeholder="12345 (5 cifre)" maxLength="5" pattern="[0-9]{5}" required />
              </div>

              <div className="form-group">
                <label className="form-label">CRYPTO WALLET ID</label>
                <input type="text" className="form-input persona-input" value={checkoutData.wallet} onChange={(e) => handleInputChange('wallet', e.target.value)} placeholder="0x1234567890abcdef1234567890abcdef12345678" maxLength="42" pattern="0x[a-fA-F0-9]{40}" required />
                <div style={{ fontSize: '0.75rem', color: 'rgba(0, 255, 255, 0.6)', marginTop: '0.5rem' }}>
                  Formato: 0x seguito da 40 caratteri esadecimali
                </div>
              </div>

              <div className="cart-summary persona-summary" style={{ marginTop: '2rem' }}>
                <div className="summary-row"><span>ITEMS:</span><span style={{ color: '#0ff' }}>{getTotalItems()}</span></div>
                <div className="summary-row summary-total"><span>TRASFERIMENTO RICHIESTO:</span><span>₿{getTotalPrice()}</span></div>
              </div>

              <button type="submit" className="submit-btn persona-btn">🔒 AUTORIZZA TRANSAZIONE</button>
            </form>
          </div>
        )}

        <div className="mascot-container" onMouseEnter={() => setGuide('Questo è Femo — il mascotte del mercato. Commenta le tue azioni in tempo reale.')} onMouseLeave={clearGuide}>
          <div className="mascot-bubble persona-bubble">
            <p className="mascot-text">{mascotMessage}</p>
          </div>
          <div ref={eyeRef}>
            <svg className="mascot-eye" viewBox="0 0 1000 1000" width="120" height="120">
              <defs>
                <filter id="mascotGlow">
                  <feGaussianBlur stdDeviation="1.5" result="coloredBlur"/>
                  <feMerge>
                    <feMergeNode in="coloredBlur"/>
                    <feMergeNode in="SourceGraphic"/>
                  </feMerge>
                </filter>
                <clipPath id="mascotClip">
                  <path d="M 350 500 C 390 430, 440 400, 500 400 C 560 400, 610 430, 650 500 C 610 570, 560 600, 500 600 C 440 600, 390 570, 350 500 Z"/>
                </clipPath>
              </defs>
              <path d="M 350 500 C 390 430, 440 400, 500 400 C 560 400, 610 430, 650 500 C 610 570, 560 600, 500 600 C 440 600, 390 570, 350 500 Z" fill="none" stroke="rgba(0, 255, 255, 0.95)" strokeWidth="12" strokeLinecap="round" strokeLinejoin="round" filter="url(#mascotGlow)"/>
              <g clipPath="url(#mascotClip)">
                <circle cx={pupilPosition.x} cy={pupilPosition.y} r="80" fill="none" stroke="rgba(0, 255, 255, 0.95)" strokeWidth="10" filter="url(#mascotGlow)"/>
                <circle cx={pupilPosition.x} cy={pupilPosition.y} r="35" fill="none" stroke="rgba(0, 255, 255, 0.95)" strokeWidth="8" filter="url(#mascotGlow)"/>
              </g>
            </svg>
          </div>
        </div>
      </div>
    </div>
  );
};

export default FemosBlackMarketPage;