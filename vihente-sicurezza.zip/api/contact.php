<?php
/**
 * VIHENTE CONTACT FORM API
 * Sistema email per Hostinger
 */

// Sicurezza: mai rivelare path o stack trace PHP al client (info disclosure).
ini_set('display_errors', '0');
ini_set('log_errors', '1');
error_reporting(E_ALL);

// ==================== CONFIGURA QUI LE TUE EMAIL ====================

// Email dove RICEVERE i contatti (può essere Gmail, Outlook, etc.)
define('ADMIN_EMAIL', 'vihenteweb@proton.me');

// Email di INVIO (meglio se del tuo dominio per deliverability)
define('FROM_EMAIL', 'noreply@vihente.it');
define('FROM_NAME', 'Portfolio Vihente');

// Domini consentiti (CORS). NB: in produzione niente localhost.
// Per testare il PHP da locale, riaggiungi temporaneamente le righe localhost.
$allowed_origins = [
    'https://vihente.it',
    'https://www.vihente.it'
];

// ========================================================================

// Configurazioni avanzate (puoi lasciare cosi)
define('RATE_LIMIT_SECONDS', 60);    // Tempo minimo tra invii (60 sec)
define('ENABLE_LOGGING', true);       // Abilita log in contacts.log
define('SEND_AUTO_REPLY', false);     // OFF: l'auto-reply a email arbitrarie e' un vettore di backscatter/spam

// Security headers
header('Content-Type: application/json; charset=UTF-8');
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: DENY');
header('X-XSS-Protection: 1; mode=block');

// CORS
$origin = isset($_SERVER['HTTP_ORIGIN']) ? $_SERVER['HTTP_ORIGIN'] : '';
if (in_array($origin, $allowed_origins)) {
    header("Access-Control-Allow-Origin: $origin");
} else {
    header("Access-Control-Allow-Origin: " . $allowed_origins[0]);
}
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type');
header('Access-Control-Max-Age: 86400');

// Preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(200);
    exit();
}

// Solo POST consentito
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Metodo non consentito']);
    exit();
}

session_start();

// Rate Limiting (file-based per IP: robusto, non dipende dal cookie di sessione)
function rateLimitFile() {
    $ip  = $_SERVER['REMOTE_ADDR'] ?? '0.0.0.0';
    $dir = __DIR__ . '/.ratelimit';
    if (!is_dir($dir)) { @mkdir($dir, 0700, true); }
    return $dir . '/' . hash('sha256', $ip);
}

function checkRateLimit() {
    $now  = time();
    $file = rateLimitFile();

    if (is_file($file)) {
        $time_elapsed = $now - (int) @file_get_contents($file);
        if ($time_elapsed < RATE_LIMIT_SECONDS) {
            $wait_time = RATE_LIMIT_SECONDS - $time_elapsed;
            http_response_code(429);
            echo json_encode([
                'success' => false,
                'message' => "Attendi ancora $wait_time secondi prima di inviare un nuovo messaggio.",
                'retry_after' => $wait_time
            ]);
            exit();
        }
    }
}

function sanitizeData($data) {
    return htmlspecialchars(strip_tags(trim((string) $data)), ENT_QUOTES, 'UTF-8');
}

// Rimuove CR/LF/TAB e caratteri di controllo: previene l'email header injection
// quando un valore finisce in Subject/From/Reply-To.
function sanitizeHeader($data) {
    $clean = preg_replace('/[\r\n\t\x00-\x1F\x7F]+/', ' ', (string) $data);
    return trim(mb_substr($clean, 0, 200));
}

// Neutralizza newline e separatori: previene la log injection (righe falsificate).
function sanitizeLogField($data) {
    return preg_replace('/[\r\n\x00-\x1F\x7F|]+/', ' ', (string) $data);
}

function validateEmail($email) {
    $email = filter_var($email, FILTER_SANITIZE_EMAIL);
    return filter_var($email, FILTER_VALIDATE_EMAIL);
}

function isSpam($data) {
    $spam_patterns = [
        'viagra', 'cialis', 'casino', 'poker', 'lottery',
        'crypto', 'bitcoin', 'investment', 'mlm', 'forex',
        'weight loss', 'prescription', 'click here', 'buy now',
        '<script', 'javascript:', 'onclick', 'onerror'
    ];

    $combined_text = strtolower($data['name'] . ' ' . $data['email'] . ' ' . $data['message']);

    foreach ($spam_patterns as $pattern) {
        if (stripos($combined_text, $pattern) !== false) {
            return true;
        }
    }

    if (substr_count($combined_text, 'http') > 2) {
        return true;
    }

    return false;
}

function logContact($data, $status = 'success') {
    if (!ENABLE_LOGGING) return;

    $log_file = __DIR__ . '/contacts.log';
    $timestamp = date('Y-m-d H:i:s');
    $ip = $_SERVER['REMOTE_ADDR'];

    $log_entry = sprintf(
        "[%s] [%s] %s | %s | %s\n",
        $timestamp,
        strtoupper($status),
        sanitizeLogField($data['name']),
        sanitizeLogField($data['email']),
        sanitizeLogField($data['service'] ?? $data['reason'] ?? 'N/A')
    );

    file_put_contents($log_file, $log_entry, FILE_APPEND | LOCK_EX);
}

function getAdminEmailTemplate($data) {
    $type = isset($data['service']) ? 'Richiesta Preventivo' : 'Contatto Generale';
    
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>';
    $html .= '<body style="font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px;">';
    $html .= '<div style="max-width: 600px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">';
    
    // Header
    $html .= '<div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px; text-align: center;">';
    $html .= "<h1 style='margin: 0; color: white; font-size: 28px;'>Nuovo {$type}</h1>";
    $html .= '<p style="margin: 10px 0 0 0; color: #e0e0e0;">Ricevuto dal form contatti</p>';
    $html .= '</div>';
    
    // Content
    $html .= '<div style="padding: 30px;">';
    
    // Nome
    $html .= '<div style="margin-bottom: 20px; padding: 15px; background: #f8f9fa; border-left: 4px solid #667eea;">';
    $html .= '<p style="margin: 0 0 5px 0; font-size: 12px; color: #6c757d; text-transform: uppercase;">Nome/Azienda</p>';
    $html .= "<p style='margin: 0; font-size: 18px; font-weight: 600;'>{$data['name']}</p>";
    $html .= '</div>';
    
    // Email
    $html .= '<div style="margin-bottom: 20px; padding: 15px; background: #f8f9fa; border-left: 4px solid #28a745;">';
    $html .= '<p style="margin: 0 0 5px 0; font-size: 12px; color: #6c757d; text-transform: uppercase;">Email</p>';
    $html .= "<p style='margin: 0; font-size: 16px;'><a href='mailto:{$data['email']}' style='color: #667eea; text-decoration: none;'>{$data['email']}</a></p>";
    $html .= '</div>';
    
    // Servizio o Motivo
    if (isset($data['service'])) {
        $html .= '<div style="margin-bottom: 20px; padding: 15px; background: #fff3cd; border-left: 4px solid #ffc107;">';
        $html .= '<p style="margin: 0 0 5px 0; font-size: 12px; color: #856404; text-transform: uppercase;">Servizio richiesto</p>';
        $html .= "<p style='margin: 0; font-size: 16px; color: #856404; font-weight: 600;'>{$data['service']}</p>";
        $html .= '</div>';
    } elseif (isset($data['reason'])) {
        $html .= '<div style="margin-bottom: 20px; padding: 15px; background: #d1ecf1; border-left: 4px solid #17a2b8;">';
        $html .= '<p style="margin: 0 0 5px 0; font-size: 12px; color: #0c5460; text-transform: uppercase;">Motivo contatto</p>';
        $html .= "<p style='margin: 0; font-size: 16px; color: #0c5460; font-weight: 600;'>{$data['reason']}</p>";
        $html .= '</div>';
    }
    
    // Messaggio
    $html .= '<div style="margin-bottom: 20px; padding: 20px; background: #f8f9fa; border-radius: 6px;">';
    $html .= '<p style="margin: 0 0 10px 0; font-size: 12px; color: #6c757d; text-transform: uppercase;">Messaggio</p>';
    $html .= "<p style='margin: 0; font-size: 15px; line-height: 1.7; white-space: pre-wrap;'>{$data['message']}</p>";
    $html .= '</div>';
    
    // CTA
    $html .= '<div style="text-align: center; margin: 30px 0; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); border-radius: 6px;">';
    $html .= "<a href='mailto:{$data['email']}' style='color: white; text-decoration: none; font-size: 16px; font-weight: 600;'>Rispondi a {$data['name']}</a>";
    $html .= '</div>';
    
    $html .= '</div>';
    
    // Footer
    $html .= '<div style="padding: 20px; background: #f8f9fa; border-top: 1px solid #dee2e6; font-size: 12px; color: #6c757d;">';
    $html .= "<p style='margin: 5px 0;'><strong>Data:</strong> {$data['timestamp']}</p>";
    $html .= "<p style='margin: 5px 0;'><strong>IP:</strong> {$data['ip']}</p>";
    $html .= "<p style='margin: 5px 0;'><strong>Privacy:</strong> Consenso GDPR confermato</p>";
    $html .= '</div>';
    
    $html .= '</div></body></html>';
    
    return $html;
}

function getUserAutoReplyTemplate($data) {
    $greeting = isset($data['service']) ? 'Grazie per la richiesta di preventivo!' : 'Grazie per avermi contattato!';
    
    $html = '<!DOCTYPE html><html><head><meta charset="UTF-8"></head>';
    $html .= '<body style="font-family: Arial, sans-serif; background: #f4f4f4; padding: 20px;">';
    $html .= '<div style="max-width: 600px; margin: 0 auto; background: white; border-radius: 12px; overflow: hidden; box-shadow: 0 4px 20px rgba(0,0,0,0.1);">';
    
    $html .= '<div style="background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 40px; text-align: center;">';
    $html .= '<h1 style="margin: 0; color: white; font-size: 28px;">Messaggio Ricevuto</h1>';
    $html .= '</div>';
    
    $html .= '<div style="padding: 40px;">';
    $html .= "<p style='margin: 0 0 20px 0; font-size: 18px;'>Ciao <strong>{$data['name']}</strong>,</p>";
    $html .= "<p style='margin: 0 0 20px 0; font-size: 16px; line-height: 1.6;'>{$greeting}</p>";
    $html .= "<p style='margin: 0 0 30px 0; font-size: 16px; line-height: 1.6;'>Ho ricevuto correttamente la tua richiesta e ti rispondero entro <strong>24-48 ore</strong>.</p>";
    
    $html .= '<div style="padding: 20px; background: #f8f9fa; border-radius: 6px; margin: 20px 0;">';
    $html .= '<p style="margin: 0 0 10px 0; font-size: 14px; font-weight: 600;">RIEPILOGO RICHIESTA</p>';
    if (isset($data['service'])) {
        $html .= "<p style='margin: 5px 0; font-size: 14px;'><strong>Servizio:</strong> {$data['service']}</p>";
    } elseif (isset($data['reason'])) {
        $html .= "<p style='margin: 5px 0; font-size: 14px;'><strong>Motivo:</strong> {$data['reason']}</p>";
    }
    $html .= "<p style='margin: 5px 0; font-size: 14px;'><strong>Email:</strong> {$data['email']}</p>";
    $html .= '</div>';
    
    $html .= '</div>';
    
    $html .= '<div style="padding: 30px; background: #f8f9fa; text-align: center; border-top: 1px solid #dee2e6;">';
    $html .= '<p style="margin: 0 0 10px 0; font-size: 16px; font-weight: 600;">A presto!</p>';
    $html .= '<p style="margin: 0 0 5px 0; font-size: 14px;">Portfolio Vihente</p>';
    $html .= '<p style="margin: 0; font-size: 12px; color: #6c757d;">Email automatica di conferma</p>';
    $html .= '</div>';
    
    $html .= '</div></body></html>';
    
    return $html;
}

// ==================== MAIN EXECUTION ====================

checkRateLimit();

$json = file_get_contents('php://input');
$input = json_decode($json, true);

if (!$input) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Dati non validi']);
    exit();
}

// Honeypot: campo invisibile riempito solo dai bot.
if (isset($input['_honeypot']) && !empty($input['_honeypot'])) {
    http_response_code(200);
    echo json_encode(['success' => true]); // niente segnale al bot
    exit();
}

// Token temporale anti-bot: il form invia _ts (ms epoch) al montaggio.
// Submit istantaneo (bot) o form troppo vecchio (replay) -> scartato in
// silenzio con la stessa risposta dell'honeypot.
$ts = isset($input['_ts']) ? (int) $input['_ts'] : 0;
$delta = (time() * 1000) - $ts;
if ($ts <= 0 || $delta < 2000 || $delta > 3600000) {
    http_response_code(200);
    echo json_encode(['success' => true]);
    exit();
}

// Consenso privacy: obbligatorio lato SERVER (GDPR), non solo nel front-end.
if (!isset($input['privacyConsent']) || $input['privacyConsent'] !== true) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Consenso privacy obbligatorio']);
    exit();
}

// Validazione campi
$required_fields = ['name', 'email', 'message'];
foreach ($required_fields as $field) {
    if (!isset($input[$field]) || empty(trim($input[$field]))) {
        http_response_code(400);
        echo json_encode(['success' => false, 'message' => "Campo mancante: $field"]);
        exit();
    }
}

// Sanitizza
$data = [
    'name' => sanitizeData($input['name']),
    'email' => sanitizeData($input['email']),
    'message' => sanitizeData($input['message']),
    'timestamp' => date('d/m/Y H:i:s'),
    'ip' => $_SERVER['REMOTE_ADDR']
];

if (isset($input['service']) && !empty($input['service'])) {
    $data['service'] = sanitizeData($input['service']);
}
if (isset($input['reason']) && !empty($input['reason'])) {
    $data['reason'] = sanitizeData($input['reason']);
}

// Validazioni
if (!validateEmail($data['email'])) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Email non valida']);
    exit();
}

if (strlen($data['name']) < 2 || strlen($data['message']) < 10) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Dati troppo corti']);
    exit();
}

// Tetto massimo: evita abusi (mail enormi) anche entro post_max_size.
if (mb_strlen($data['name']) > 100 || mb_strlen($data['message']) > 5000) {
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Dati troppo lunghi']);
    exit();
}

if (isSpam($data)) {
    logContact($data, 'spam');
    http_response_code(400);
    echo json_encode(['success' => false, 'message' => 'Messaggio bloccato']);
    exit();
}

// Invia email ADMIN
$admin_subject = isset($data['service'])
    ? sanitizeHeader("Preventivo: {$data['service']} - {$data['name']}")
    : sanitizeHeader("Contatto: {$data['name']}");

$admin_body = getAdminEmailTemplate($data);

$admin_headers = [
    'MIME-Version: 1.0',
    'Content-Type: text/html; charset=UTF-8',
    'From: ' . FROM_NAME . ' <' . FROM_EMAIL . '>',
    'Reply-To: ' . sanitizeHeader($data['email'])
];

$admin_sent = mail(ADMIN_EMAIL, $admin_subject, $admin_body, implode("\r\n", $admin_headers));

if (!$admin_sent) {
    logContact($data, 'error');
    http_response_code(500);
    echo json_encode(['success' => false, 'message' => 'Errore invio']);
    exit();
}

// Auto-reply utente
if (SEND_AUTO_REPLY) {
    $user_subject = 'Messaggio ricevuto - Portfolio Vihente';
    $user_body = getUserAutoReplyTemplate($data);
    $user_headers = [
        'MIME-Version: 1.0',
        'Content-Type: text/html; charset=UTF-8',
        'From: ' . FROM_NAME . ' <' . FROM_EMAIL . '>'
    ];
    mail($data['email'], $user_subject, $user_body, implode("\r\n", $user_headers));
}

logContact($data, 'success');

@file_put_contents(rateLimitFile(), (string) time(), LOCK_EX);
$_SESSION['last_submit_ip'] = $_SERVER['REMOTE_ADDR'] ?? '';
$_SESSION['last_submit_time'] = time();

http_response_code(200);
echo json_encode(['success' => true, 'message' => 'Messaggio inviato!']);
?>
