# AGGIORNAMENTO MOBILE v2 — delta completo vs main

Come il precedente + IL TOUR GUIDATO MOBILE RIFATTO:
su mobile 10 step su 12 puntavano a elementi nascosti (link navbar
desktop, logo, widget Iris...): lo spotlight illuminava il nulla.
Ora ogni step ha un bersaglio alternativo mobile (hamburger, bottone
Iris della navbar, toggle compatto) o viene saltato se l'elemento
narrato non esiste; pannello mai piu' largo del viewport, bottoni a
44px, fallback centrato se un bersaglio sparisce.

Copia le cartelle sopra la root sovrascrivendo. Eliminazioni (se non
gia' fatte): api/test-email.php + i 6 file orfani noti (lista nelle
versioni precedenti). Poi: node security-audit.js && npm run build.
