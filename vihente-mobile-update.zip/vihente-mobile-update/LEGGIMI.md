# AGGIORNAMENTO MOBILE — delta completo vs main

Include TUTTO il lavoro precedente (52 file gia' noti) + i 3 batch del
controllo mobile totale. Copia le cartelle sopra la root sovrascrivendo.

## Batch mobile inclusi

1. COMPATIBILITA' CROSS-BROWSER: fallback vh prima di ogni dvh (Safari
   <15.4/Chrome <108 scartavano le unita' dinamiche: altezze collassate);
   cascata overflow hidden->clip sulle sim (sticky vive sui moderni,
   niente overflow sui vecchi); text-size-adjust; tap-highlight;
   overscroll-behavior su menu/modal/sim (niente scroll della pagina
   dietro, niente pull-to-refresh accidentale).
2. CONTENUTI: tabella privacy scrollabile a 360px; input CRUD/BlackMarket
   a 16px (sotto: Safari iOS zooma al focus e resta zoomato); titoli card
   grafiche visibili su touch (erano hover-only).
3. RIFINITURE: -webkit-backdrop-filter su 71 punti (Safari iOS); zoom
   prodotto ecommerce ora funziona col dito; hamburger con area tattile
   50x45; Salone e Agenzia Viaggio con tap target e micro-font corretti.

## Da eliminare (se non gia' fatto)

api/test-email.php, public/images/Chef.webp,
"public/images/Screenshot 2026-05-19 095916_converted.webp",
public/images/websitesimage.webp, public/site.webmanifest,
public/web-app-manifest-192x192.png, public/web-app-manifest-512x512.png

## Dopo la copia

node security-audit.js && node integrity-scan.js   # 0 FAIL
npm run build
