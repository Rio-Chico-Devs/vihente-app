# AGGIORNAMENTO FINALE v2 — 56 file

Calcolato contro il tuo main pushato. Rispetto alla v1 aggiunge i fix
mobile appena fatti (4 file): glitch del menu mobile (scrollbar
fantasma), revisione completa mobile del FotografoSim, stesso bug
sticky corretto nel BarbiereSim.

## COPIA (sovrascrivi)

```
scripts/     -> NUOVA, 2 file. SENZA QUESTA npm run build FALLISCE
                (il tuo package.json chiama gia' scripts/stamp-sw.js)
public/      -> sw.js e sitemap.xml
src/         -> tutti i fix (RouteMeta e NotFound sono componenti nuovi)
```

## ELIMINA (7 file)

```
api/test-email.php
public/images/Chef.webp
public/images/Screenshot 2026-05-19 095916_converted.webp
public/images/websitesimage.webp
public/site.webmanifest
public/web-app-manifest-192x192.png
public/web-app-manifest-512x512.png
```

Facoltativo (residui dei miei pacchetti): README-UPDATE.md,
SYNC-INSTRUCTIONS.md, apply.sh

## TIENI COSI' COME SONO

package.json, vite.config.js, index.html, api/contact.php,
api/.htaccess, public/.htaccess, PricingPackages/ServiceTimeline/
FAQSection, ISTRUZIONI.txt (tuoi appunti)

## DOPO LA COPIA

```
node security-audit.js && node integrity-scan.js   # 0 FAIL
npm run build
bash scripts/resize-images.sh          # dry-run
bash scripts/resize-images.sh --apply  # resize vero (commit prima!)
```
