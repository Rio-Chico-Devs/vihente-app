# AGGIORNAMENTO FINALE — 52 file

Calcolato contro il TUO main appena pushato: dentro c'e' solo quello che
ti manca, niente che hai gia'.

## COPIA (sovrascrivi) — le cartelle rispecchiano il progetto

```
scripts/     -> NUOVA cartella, 2 file. SENZA QUESTA npm run build FALLISCE
                (il tuo package.json chiama gia' scripts/stamp-sw.js)
public/      -> solo sw.js e sitemap.xml
src/         -> tutti i fix (46 file): componenti nuovi RouteMeta e
                NotFound, piu' i file modificati dai 6 round
```

## ELIMINA (7 file)

```
api/test-email.php
public/images/Chef.webp
public/images/Screenshot 2026-05-19 095916_converted.webp
public/images/websitesimage.webp
public/site.webmanifest
public/web-app-manifest-192x192.png
public/web-app-manifest-512x512.png
```

Facoltativo (spazzatura dei miei pacchetti precedenti, non serve a nulla):
```
README-UPDATE.md
SYNC-INSTRUCTIONS.md
apply.sh
```

## TIENI COSI' COME SONO (gia' aggiornati sul tuo main)

```
package.json          vite.config.js       index.html
api/contact.php       api/.htaccess        public/.htaccess
src/components/global/PricingPackages|ServiceTimeline|FAQSection
ISTRUZIONI.txt        (i tuoi appunti)
```

## DOPO LA COPIA

```
node security-audit.js    # 0 FAIL atteso
node integrity-scan.js    # 0 FAIL atteso
npm run build             # ora funziona (prima falliva: mancava scripts/)
bash scripts/resize-images.sh          # dry-run immagini
bash scripts/resize-images.sh --apply  # resize vero (commit prima!)
```
