import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react-swc'

// https://vite.dev/config/
export default defineConfig(({ mode }) => ({
  plugins: [react()],
  
  base: '/',
  
  build: {
    minify: 'esbuild',
    cssMinify: true,
    rollupOptions: {
      output: {
        manualChunks: {
          'react-vendor': ['react', 'react-dom', 'react-router-dom'],
          'utils-vendor': ['validator']
        }
      }
    },
    chunkSizeWarningLimit: 1000
  },
  
  esbuild: {
    drop: mode === 'production' ? ['console', 'debugger'] : []
  },
  
  server: {
    port: 3000,
    open: true
  },
  
  preview: {
    port: 4173,
    open: true
  }
}))
