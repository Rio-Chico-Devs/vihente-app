# AGGIORNAMENTO — CTA forte: pacchetti + tempi + FAQ + preventivo

Questo pacchetto trasforma il sito da "portfolio premium" a "funnel di
vendita base": ogni pagina servizio ora ha pacchetti con prezzi
indicativi, tempi di consegna tipici, FAQ pre-vendita, e CTA diretto al
form preventivo (riattivato).

## Cosa cambia per l'utente del sito

- Visita /services/consulenze (o /sitiweb, /presenza, /multimedia)
- Vede 3 pacchetti con prezzi indicativi
- Vede la timeline tipica dal primo contatto alla consegna
- Trova 5-6 FAQ con risposte oneste
- Click su "Richiedi preventivo" -> arriva a /contatti gia' in modalita'
  preventivo con il servizio pre-selezionato

## Modificare i prezzi

I prezzi sono inseriti come costanti JS in cima a ogni pagina servizio.
Sono editabili in 30 secondi:

```
src/components/sections/ConsulenzePage/ConsulenzePage.jsx   -> CONSULENZE_PACKAGES
src/components/sections/SitiWebPage/SitiWebPage.jsx          -> SITIWEB_PACKAGES
src/components/sections/PresenzaOnline/PresenzaOnlinePage.jsx -> PRESENZA_PACKAGES
src/components/sections/MultimediaPage/MultimediaPage.jsx    -> MULTIMEDIA_PACKAGES
```

Idem per timeline e FAQ. Tutto il contenuto editoriale e' raggruppato
in 3 const all'inizio di ogni file.

## File nuovi nel pacchetto (componenti riusabili)

```
src/components/global/PricingPackages/PricingPackages.jsx  + .css
src/components/global/ServiceTimeline/ServiceTimeline.jsx  + .css
src/components/global/FAQSection/FAQSection.jsx            + .css
```

## File modificati

```
src/components/sections/Contacts/Contacts.jsx              [+ pre-fill quote + toggle visibile]
src/components/sections/ConsulenzePage/ConsulenzePage.jsx  [+ pacchetti/tempi/FAQ]
src/components/sections/SitiWebPage/SitiWebPage.jsx        [+ pacchetti/tempi/FAQ]
src/components/sections/PresenzaOnline/PresenzaOnlinePage.jsx [+ pacchetti/tempi/FAQ]
src/components/sections/MultimediaPage/MultimediaPage.jsx  [+ pacchetti/tempi/FAQ]
```

Pius i file delle rifiniture precedenti (api/contact.php, public/.htaccess,
GraficheShowcase.jsx/.css, vite.config.js) se ancora non li avevi applicati.

## Cosa fare

1. Estrai lo zip.
2. Copia tutto sopra il repo `main`, sovrascrivendo.
3. **Cancella manualmente `api/test-email.php`** se ancora presente
   (espone versione PHP, va via prima del deploy).
4. Verifica:
   ```
   node security-audit.js   # 0 FAIL atteso
   node integrity-scan.js   # 0 FAIL atteso
   npm install
   npm run build
   ```

## Modalita' preventivo: come si attiva

Sul form contatti il toggle "Richiedi un Preventivo" e' di nuovo visibile.
Inoltre arrivando da una pagina servizio con click sul CTA del pacchetto,
l'utente atterra su:

  /contatti?mode=quote&service=Consulenza

Contacts.jsx legge la query string al mount, attiva la modalita'
preventivo e pre-seleziona il servizio nel dropdown. Se manca uno dei
due parametri si comporta come prima.
